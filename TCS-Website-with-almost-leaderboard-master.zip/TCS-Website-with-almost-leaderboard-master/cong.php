<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="cong.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
</head>

<body>
<div class="cong">
    <form>
        <h2 style="color: white">Congratulations you Log In successfully!!!</h2>
        <a href="logn.php" style="text-decoration: none">Go back to Home page</a>
        <br><br>
    </form>

    </div>
</body>
</html>
