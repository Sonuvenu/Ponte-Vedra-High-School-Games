<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="logn.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
</head>

<body>
   <div class="signin">

<form action = "validation.php" method = "post">
<h2 style="color:#fff;">Log In</h2>
<input type="text" name="user" placeholder="Username"/><br /><br />
<input type="password" name="password" placeholder="Password" /><br /><br />
<a href="home.php"><input type="submit" value="Log In" /></a><br /><br />
<div id="container">

    <a href="for.php" style=" margin: center ; font-size:13px; font-family:Tahoma, Geneva, sans-serif;">Forgot password?</a>
    </div><br /><br /><br /><br /><br /><br />
Don't have account?<a href="sgnup.php" style="font-family:'Play', sans-serif;">&nbsp;Sign Up</a>
<a href="guesthome.php" style="font-family:'Play', sans-serif;">&nbsp;Login as Guest</a>

</form>
</div>

</body>
</html>
